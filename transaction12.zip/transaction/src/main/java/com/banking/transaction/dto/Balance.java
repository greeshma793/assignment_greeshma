package com.banking.transaction.dto;

import java.time.Month;
import java.util.Map;
public class Balance {
	 private int cumulativeBalance;
	    private Map<Month, Integer> monthlyBalances;

	    public Balance(int cumulativeBalance, Map<Month, Integer> monthlyBalances) {
	        this.cumulativeBalance = cumulativeBalance;
	        this.monthlyBalances = monthlyBalances;
	    }

	    public int getCumulativeBalance() {
	        return cumulativeBalance;
	    }

	    public Map<Month, Integer> getMonthlyBalances() {
	        return monthlyBalances;
	    }
}
