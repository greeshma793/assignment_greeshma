package com.banking.transaction.controller;

import java.time.LocalDate;
import java.time.Month;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

import com.banking.transaction.dto.Balance;
import com.banking.transaction.dto.Transaction;

@RestController
public class TransactionController {

	private List<Transaction> transactions;

	public TransactionController() {
		// initializing mock transactions
		transactions = new ArrayList<>();
		transactions.add(new Transaction(1000, LocalDate.of(2022, 1, 1)));
		transactions.add(new Transaction(2000, LocalDate.of(2022, 2, 1)));
		transactions.add(new Transaction(3000, LocalDate.of(2022, 3, 1)));
		transactions.add(new Transaction(1000, LocalDate.of(2022, 1, 10)));
		transactions.add(new Transaction(2000, LocalDate.of(2022, 2, 11)));
		transactions.add(new Transaction(3000, LocalDate.of(2022, 3, 12)));
		transactions.add(new Transaction(1000, LocalDate.of(2022, 1, 11)));
		transactions.add(new Transaction(2000, LocalDate.of(2022, 2, 21)));
		transactions.add(new Transaction(3000, LocalDate.of(2022, 3, 22)));
	}

	@GetMapping("/getTransaction/balance")
	public Balance getBalance() {
		Map<Month, Integer> monthlyBalances = new HashMap<>();
		int cumulativeBalance = 0;

		for (Transaction transaction : transactions) {
			int amount = transaction.getAmount();
			LocalDate date = transaction.getDate();

			cumulativeBalance += amount;

			Month month = date.getMonth();
			if (!monthlyBalances.containsKey(month)) {
				monthlyBalances.put(month, 0);
			}
			monthlyBalances.put(month, monthlyBalances.get(month) + amount);
		}

		return new Balance(cumulativeBalance, monthlyBalances);
	}
}
